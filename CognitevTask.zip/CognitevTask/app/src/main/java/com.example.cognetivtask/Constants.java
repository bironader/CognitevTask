package com.example.cognetivtask;

public final class Constants {

    public static final String TOKEN_TAG = "ACCESS_TOKEN";
}
