package com.example.cognetivtask.features.viewmodel.main;

import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

public class MainViewModel extends ViewModel {


    @Inject
    MainViewModel() {

    }
}
